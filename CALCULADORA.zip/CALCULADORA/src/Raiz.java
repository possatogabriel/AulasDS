/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// IMPORTAR BIBLIOTECA DE MATEMÁTICA
import java.lang.Math;
/**
 *
 * @author Aluno CA
 */
public class Raiz {
    
    double numero1;
    
    void setNumero1(int num1){
        this.numero1 = num1;
    }
    
    double radiciar(){
        //MATH.SQRT - COMANDO PARA FAZER A RAÍZ QUADRADA (VARÍAVEL "a": RADICANDO)
        return Math.sqrt(numero1);
    }
}
