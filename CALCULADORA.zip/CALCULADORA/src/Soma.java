/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno CA
 */
public class Soma {
    
    int numero1, numero2;
    
    void setNumero1(int num1){
        this.numero1 = num1;
    }
    
    void setNumero2(int num2){
        this.numero2 = num2;
    }
    
    int somar(){
        return numero1 + numero2;
    }
}
