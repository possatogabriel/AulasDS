/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno CA
 */
public class Divisao {
    
    float numero1, numero2;
    
    void setNumero1(float num1) {
        this.numero1 = num1;
    }
    
    void setNumero2(float num2) {
        this.numero2 = num2;
    }
    
    float dividir(){
        return numero1 / numero2;
    }
    
}
