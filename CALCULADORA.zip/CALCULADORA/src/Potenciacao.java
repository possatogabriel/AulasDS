/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// IMPORTAR BIBLIOTECA DE MATEMÁTICA
import java.lang.Math;
/**
 *
 * @author Aluno CA
 */
public class Potenciacao {
    
    double numero1, numero2;
    
    void setNumero1 (double num1) {
        this.numero1 = num1;
    }    
    
    void setNumero2 (double num2) {
        this.numero2 = num2;
    }
    
    double potenciar() {
        //MATH.POW - COMANDO PARA FAZER A POTENCIAÇÃO (VARÍAVEL "a": BASE - VARÍAVEL "b": POTÊNCIA)
        return Math.pow(numero1, numero2);
    }
    
}
